const EN = {
    "title": "Yussef makhlouf ",
    "description": "computer science graduate  ",
    "home": "Final Task  ", 
}


export default EN; 