const AR = {
    "title": "يوسف مخلوف",
    "description": "خريج بكلية الحاسبات",
    "home": "المهمة النهائية",
    
}

export default AR; 

